

#ifndef menu_hpp
#define menu_hpp

#include "Queue.hpp"
#include <stdio.h>
#include <iostream>


void display_creatures();
void display_creature_prompt(int num_creat);
void display_win_team_points(int p1_points, int p2_points);

#endif