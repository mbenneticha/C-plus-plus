

#ifndef Damage_h
#define Damage_h

int calc_damage(int attack, int defense);

#endif 
