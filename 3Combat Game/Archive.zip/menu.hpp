

#ifndef menu_hpp
#define menu_hpp

int main_menu();
int combat_menu();

#endif /* menu_hpp */
